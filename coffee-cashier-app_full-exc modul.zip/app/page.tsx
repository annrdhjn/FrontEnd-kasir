import React from 'react'

const HomePage = () => {
  return (
    <div>
      <h1>Ini halaman HomePage</h1>
    </div>
  );
}

export default HomePage